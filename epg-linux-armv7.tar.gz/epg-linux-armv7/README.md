# EPG 系统 - Linux armv7 二进制发布版

## 包含内容
- `epg-server` : 后端二进制 (armv7-unknown-linux-gnueabihf)
- `web/`       : 前端静态文件 (Vue 3 + Vite build)
- `config.yml` : 后端配置 (监听 0.0.0.0:8080)
- `migrations/`: SQLite 迁移脚本 (启动时自动应用)
- `run.sh`     : 一键安装/启动/停止/卸载脚本

## 快速开始
```bash
chmod +x run.sh epg-server
./run.sh           # 一键安装并启动 (创建 /opt/epg + admin/admin123)
./run.sh menu      # 交互菜单
./run.sh stop      # 停止
./run.sh uninstall # 卸载
```

## 默认账号
- 用户名: `admin`
- 密  码: `admin123`

⚠️ 首次登录后请立即在后台修改密码！

## 端口
- 后端 API : 8080
- 前端页面 : 8081

## 数据
- 数据目录: `/opt/epg` (脚本自动创建)
- 数据库  : `/opt/epg/data/epg.db`
- 密码文件: `/opt/epg/epg.htpasswd`
