#!/usr/bin/env bash
# EPG 系统 - 服务器端运行脚本 (二进制发布版)
# 功能：检测/创建 /opt/epg，初始化默认账号，启动后端 + 前端静态服务
set -e

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BLUE='\033[0;34m'
NC='\033[0m'

log()   { echo -e "${GREEN}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERR ]${NC} $*"; exit 1; }

EPG_DIR="${EPG_DIR:-/opt/epg}"
BACKEND_PORT="${BACKEND_PORT:-8080}"
FRONTEND_PORT="${FRONTEND_PORT:-8081}"
DEFAULT_USER="${EPG_DEFAULT_USER:-admin}"
DEFAULT_PASS="${EPG_DEFAULT_PASS:-admin123}"
HTPASSWD_PATH="${EPG_HTPASSWD_PATH:-$EPG_DIR/epg.htpasswd}"
export EPG_HTPASSWD_PATH="$HTPASSWD_PATH"

SUDO=""
if [ "$(id -u)" != "0" ]; then
  command -v sudo >/dev/null 2>&1 && SUDO="sudo"
fi

# ---------- 准备目录 ----------
prepare_dir() {
  log "[1/5] 检测目录 $EPG_DIR ..."
  if [ ! -d "$EPG_DIR" ]; then
    $SUDO mkdir -p "$EPG_DIR"/{data,logs,conf}
    log "  - 已创建 $EPG_DIR"
  else
    log "  - 已存在 ✅"
  fi
  $SUDO mkdir -p "$EPG_DIR/data" "$EPG_DIR/logs" "$EPG_DIR/conf"
  CUR_USER="$(id -un)"; CUR_GROUP="$(id -gn)"
  [ -n "$SUDO" ] && $SUDO chown -R "$CUR_USER:$CUR_GROUP" "$EPG_DIR" || true
  $SUDO chmod -R 755 "$EPG_DIR" || true
}

# ---------- 安装可选系统依赖 ----------
ensure_htpasswd() {
  if command -v htpasswd >/dev/null 2>&1; then return 0; fi
  warn "未检测到 htpasswd，正在安装..."
  if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get update -y && $SUDO apt-get install -y apache2-utils
  elif command -v dnf >/dev/null 2>&1; then
    $SUDO dnf install -y httpd-tools
  elif command -v yum >/dev/null 2>&1; then
    $SUDO yum install -y httpd-tools
  elif command -v apk >/dev/null 2>&1; then
    $SUDO apk add --no-cache apache2-utils
  elif command -v pacman >/dev/null 2>&1; then
    $SUDO pacman -Sy --noconfirm apache
  fi
}

ensure_python() {
  if command -v python3 >/dev/null 2>&1; then return 0; fi
  if command -v python >/dev/null 2>&1; then return 0; fi
  warn "未检测到 python3，正在安装 (用于前端静态文件服务)..."
  if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get update -y && $SUDO apt-get install -y python3
  elif command -v dnf >/dev/null 2>&1; then
    $SUDO dnf install -y python3
  elif command -v yum >/dev/null 2>&1; then
    $SUDO yum install -y python3
  elif command -v apk >/dev/null 2>&1; then
    $SUDO apk add --no-cache python3
  fi
}

# ---------- 初始化账号 ----------
init_account() {
  log "[2/5] 初始化默认账号..."
  if [ -f "$HTPASSWD_PATH" ]; then
    log "  - 已存在: $HTPASSWD_PATH ✅"
  else
    ensure_htpasswd
    if command -v htpasswd >/dev/null 2>&1; then
      htpasswd -bcB "$HTPASSWD_PATH" "$DEFAULT_USER" "$DEFAULT_PASS" >/dev/null 2>&1 \
        || $SUDO htpasswd -bcB "$HTPASSWD_PATH" "$DEFAULT_USER" "$DEFAULT_PASS" >/dev/null 2>&1
      log "  - 创建默认账号 $DEFAULT_USER / $DEFAULT_PASS"
    fi
  fi
}

# ---------- 启动 ----------
start_services() {
  log "[3/5] 准备运行环境..."
  ensure_python
  chmod +x "$ROOT/epg-server" 2>/dev/null || true

  mkdir -p "$ROOT/logs"
  # 数据/配置目录优先用 EPG_DIR
  ln -sfn "$EPG_DIR/data" "$ROOT/data" 2>/dev/null || true

  # 停止旧进程
  for pidf in "$ROOT/logs/server.pid" "$ROOT/logs/web.pid"; do
    if [ -f "$pidf" ]; then
      OLD_PID="$(cat "$pidf" 2>/dev/null || true)"
      if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        warn "  - 停止旧进程 PID=$OLD_PID"
        kill "$OLD_PID" 2>/dev/null || true; sleep 1
      fi
      rm -f "$pidf"
    fi
  done

  log "[4/5] 启动后端..."
  cd "$ROOT"
  EPG_HTPASSWD_PATH="$HTPASSWD_PATH" \
    nohup ./epg-server > "$ROOT/logs/server.log" 2>&1 &
  SERVER_PID=$!
  echo $SERVER_PID > "$ROOT/logs/server.pid"
  log "  - 后端 PID=$SERVER_PID, 日志: logs/server.log"

  log "[5/5] 启动前端 (静态文件 http.server)..."
  cd "$ROOT/web"
  PYBIN="$(command -v python3 || command -v python)"
  if [ -z "$PYBIN" ]; then
    warn "  - 未找到 python，前端无法启动。请用 nginx 或其他静态服务器托管 web/ 目录"
  else
    nohup "$PYBIN" -m http.server "$FRONTEND_PORT" --bind 0.0.0.0 > "$ROOT/logs/web.log" 2>&1 &
    WEB_PID=$!
    echo $WEB_PID > "$ROOT/logs/web.pid"
    log "  - 前端 PID=$WEB_PID, 日志: logs/web.log"
  fi

  cd "$ROOT"
  sleep 2
  print_finish_banner
}

print_finish_banner() {
  echo
  echo -e "${GREEN}============================================${NC}"
  echo -e "${GREEN}  ✅ EPG 系统启动完成${NC}"
  echo -e "${GREEN}============================================${NC}"
  echo -e "  后端 API   : ${CYAN}http://<server-ip>:${BACKEND_PORT}${NC}"
  echo -e "  前端页面   : ${CYAN}http://<server-ip>:${FRONTEND_PORT}${NC}"
  echo -e "  健康检查   : curl http://localhost:${BACKEND_PORT}/health"
  echo -e "  数据目录   : ${EPG_DIR}"
  echo -e "${GREEN}--------------------------------------------${NC}"
  echo -e "  🔐 ${YELLOW}默认登录账号${NC}"
  echo -e "     用户名 : ${CYAN}${DEFAULT_USER}${NC}"
  echo -e "     密  码 : ${CYAN}${DEFAULT_PASS}${NC}"
  echo -e "     htpasswd: ${HTPASSWD_PATH}"
  echo -e "  ⚠️  ${YELLOW}首次登录后请立即在后台修改密码！${NC}"
  echo -e "${GREEN}============================================${NC}"
}

stop_services() {
  log "停止服务..."
  for pidf in "$ROOT/logs/server.pid" "$ROOT/logs/web.pid"; do
    if [ -f "$pidf" ]; then
      PID="$(cat "$pidf" 2>/dev/null || true)"
      [ -n "$PID" ] && kill "$PID" 2>/dev/null && log "  - 已停止 PID=$PID" || true
      rm -f "$pidf"
    fi
  done
  pkill -f "$ROOT/epg-server" 2>/dev/null || true
  pkill -f "http.server $FRONTEND_PORT" 2>/dev/null || true
  log "✅ 已停止"
}

show_status() {
  echo "============================================"
  echo "  EPG 服务状态"
  echo "============================================"
  if pgrep -af "$ROOT/epg-server" >/dev/null; then
    pgrep -af "$ROOT/epg-server" | sed 's/^/  后端: /'
  else
    echo -e "  后端: ${RED}未运行${NC}"
  fi
  if pgrep -af "http.server $FRONTEND_PORT" >/dev/null; then
    pgrep -af "http.server $FRONTEND_PORT" | sed 's/^/  前端: /'
  else
    echo -e "  前端: ${RED}未运行${NC}"
  fi
  echo "  数据: $EPG_DIR"
  echo "============================================"
}

uninstall_all() {
  echo -e "${RED}⚠️  将卸载 EPG (停止服务 + 删除 $EPG_DIR + 删除 logs/)${NC}"
  read -r -p "确认输入 YES: " ans
  [ "$ans" != "YES" ] && { warn "取消"; return; }
  stop_services
  $SUDO rm -rf "$EPG_DIR"
  rm -rf "$ROOT/logs" "$ROOT/data"
  log "✅ 已卸载"
}

show_menu() {
  clear 2>/dev/null || true
  echo -e "${BLUE}============================================${NC}"
  echo -e "${BLUE}     EPG 系统 - 二进制版运行菜单${NC}"
  echo -e "${BLUE}============================================${NC}"
  echo -e "  目录: ${CYAN}$ROOT${NC}"
  echo -e "  数据: ${CYAN}$EPG_DIR${NC}"
  echo -e "  端口: 后端 ${CYAN}$BACKEND_PORT${NC} / 前端 ${CYAN}$FRONTEND_PORT${NC}"
  echo -e "${BLUE}--------------------------------------------${NC}"
  echo -e "  ${GREEN}1)${NC} 一键安装并启动 (初始化目录+账号+启动)"
  echo -e "  ${GREEN}2)${NC} 启动服务 (已初始化过)"
  echo -e "  ${GREEN}3)${NC} 停止服务"
  echo -e "  ${GREEN}4)${NC} 查看状态"
  echo -e "  ${RED}5)${NC} 卸载 (恢复原始状态)"
  echo -e "  ${YELLOW}0)${NC} 退出"
  echo -e "${BLUE}============================================${NC}"
}

main_menu() {
  while true; do
    show_menu
    read -r -p "请选择 [0-5]: " choice
    case "$choice" in
      1) prepare_dir; init_account; start_services; read -r -p "按回车返回..." _ ;;
      2) start_services; read -r -p "按回车返回..." _ ;;
      3) stop_services; read -r -p "按回车返回..." _ ;;
      4) show_status; read -r -p "按回车返回..." _ ;;
      5) uninstall_all; read -r -p "按回车返回..." _ ;;
      0) exit 0 ;;
      *) warn "无效选择"; sleep 1 ;;
    esac
  done
}

case "${1:-}" in
  install|"") prepare_dir; init_account; start_services ;;
  start)      start_services ;;
  stop)       stop_services ;;
  status)     show_status ;;
  uninstall)  uninstall_all ;;
  menu)       main_menu ;;
  *)          echo "用法: $0 [install|start|stop|status|uninstall|menu]"; exit 1 ;;
esac
