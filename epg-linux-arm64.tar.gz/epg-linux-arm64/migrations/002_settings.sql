-- 系统设置 KV 表
CREATE TABLE IF NOT EXISTS epg_settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);
