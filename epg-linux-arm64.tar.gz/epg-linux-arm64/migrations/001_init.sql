-- EPG SQLite Schema
-- Version: 1

CREATE TABLE IF NOT EXISTS epg_channel (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_code TEXT NOT NULL UNIQUE,
  channel_name TEXT NOT NULL,
  display_name TEXT,
  logo_url TEXT,
  category TEXT,
  language TEXT,
  country TEXT,
  sort_order INTEGER DEFAULT 0,
  status INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_channel_status ON epg_channel(status);
CREATE INDEX IF NOT EXISTS idx_channel_category ON epg_channel(category);

CREATE TABLE IF NOT EXISTS epg_program_schedule (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  channel_id INTEGER NOT NULL,
  program_title TEXT NOT NULL,
  program_subtitle TEXT,
  description TEXT,
  category TEXT,
  start_time TEXT NOT NULL,
  end_time TEXT NOT NULL,
  duration INTEGER,
  language TEXT,
  source_id INTEGER,
  version TEXT,
  status INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(channel_id) REFERENCES epg_channel(id)
);

CREATE INDEX IF NOT EXISTS idx_prog_channel_time ON epg_program_schedule(channel_id, start_time, end_time);
CREATE INDEX IF NOT EXISTS idx_prog_title ON epg_program_schedule(program_title);
CREATE INDEX IF NOT EXISTS idx_prog_start ON epg_program_schedule(start_time);

CREATE TABLE IF NOT EXISTS epg_data_source (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_name TEXT NOT NULL,
  source_type TEXT NOT NULL,        -- xmltv | json | csv
  source_url TEXT,
  file_format TEXT,                  -- xml | xml.gz | json | csv
  timezone TEXT DEFAULT 'Asia/Shanghai',
  priority INTEGER DEFAULT 0,
  sync_cron TEXT,
  status INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS epg_external_channel_mapping (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL,
  external_channel_id TEXT,
  external_channel_name TEXT,
  internal_channel_id INTEGER NOT NULL,
  match_type TEXT DEFAULT 'manual',
  status INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(source_id) REFERENCES epg_data_source(id),
  FOREIGN KEY(internal_channel_id) REFERENCES epg_channel(id)
);

CREATE INDEX IF NOT EXISTS idx_ext_map_source ON epg_external_channel_mapping(source_id, external_channel_id);

CREATE TABLE IF NOT EXISTS epg_field_mapping (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL,
  external_field TEXT NOT NULL,
  internal_field TEXT NOT NULL,
  transform_rule TEXT,
  status INTEGER DEFAULT 1,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(source_id) REFERENCES epg_data_source(id)
);

CREATE TABLE IF NOT EXISTS epg_import_preview (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER NOT NULL,
  task_id TEXT NOT NULL,
  external_channel_id TEXT,
  internal_channel_id INTEGER,
  program_title TEXT,
  description TEXT,
  start_time TEXT,
  end_time TEXT,
  raw_payload TEXT,
  status TEXT DEFAULT 'pending',     -- pending | approved | rejected | imported
  error_message TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(source_id) REFERENCES epg_data_source(id)
);

CREATE INDEX IF NOT EXISTS idx_preview_task ON epg_import_preview(task_id, status);

CREATE TABLE IF NOT EXISTS epg_sync_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id INTEGER,
  task_id TEXT,
  status TEXT,                       -- success | failed | running
  message TEXT,
  records_total INTEGER DEFAULT 0,
  records_imported INTEGER DEFAULT 0,
  started_at TEXT DEFAULT CURRENT_TIMESTAMP,
  finished_at TEXT
);
